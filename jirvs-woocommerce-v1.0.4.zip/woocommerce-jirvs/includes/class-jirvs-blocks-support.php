<?php
/**
 * Jirvs 支付网关的 WooCommerce Blocks（区块结账）支持
 *
 * 背景：WooCommerce 7+ 新装默认用区块结账页，不再走经典短代码。
 * 支付网关如果不向 Blocks 注册，结账页里根本不显示——这就是 v1.0.0 的坑。
 *
 * 这个类只负责"在区块结账页里露面"：
 *  - 标题/描述从网关设置里读（后台改了这边自动跟）
 *  - 能不能用（is_active）直接复用网关的 is_available()：
 *    没填 Key 或商户 ID 时自动隐藏，防买家点进来报错
 *  - 真正的下单逻辑还在 WC_Gateway_Jirvs::process_payment()，这边不动
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

class WC_Gateway_Jirvs_Blocks_Support extends AbstractPaymentMethodType {

    /** @var string 必须和网关的 $this->id 一致，结账时靠它找到网关类 */
    protected $name = 'jirvs';

    /** @var WC_Gateway_Jirvs|null 网关实例（读设置、判可用都靠它） */
    private $gateway = null;

    /**
     * 初始化：拿到网关实例，后面 is_active() 和取标题都用它。
     */
    public function initialize() {
        $this->settings = get_option( 'woocommerce_jirvs_settings', array() );
        if ( function_exists( 'WC' ) && WC()->payment_gateways ) {
            $gateways      = WC()->payment_gateways->payment_gateways();
            $this->gateway = isset( $gateways['jirvs'] ) ? $gateways['jirvs'] : null;
        }
    }

    /**
     * 区块结账页要不要显示 Jirvs：复用网关自己的判断。
     * （启用 + 填了 Key + 填了商户 ID 才显示）
     */
    public function is_active() {
        if ( ! $this->gateway ) {
            return false;
        }
        return $this->gateway->is_available();
    }

    /**
     * 注册前端 JS：结账页靠这段 JS 把"Jirvs 支付"画出来。
     */
    public function get_payment_method_script_handles() {
        wp_register_script(
            'jirvs-blocks',
            JIRVS_WC_PLUGIN_URL . 'assets/js/jirvs-blocks.js',
            array( 'wc-blocks-registry', 'wc-settings', 'wp-element' ),
            JIRVS_WC_VERSION,
            true
        );
        return array( 'jirvs-blocks' );
    }

    /**
     * 传给 JS 的数据：标题和描述（买家在结账页看到的字）。
     * JS 里用 window.wc.wcSettings.getSetting('jirvs_data') 取到。
     */
    public function get_payment_method_data() {
        return array(
            'title'       => $this->get_setting( 'title', '银行卡 / 本地钱包（Jirvs 安全支付）' ),
            'description' => $this->get_setting( 'description', '跳转到 Jirvs 安全收银台完成付款，支持国际信用卡与本地电子钱包。' ),
        );
    }
}
