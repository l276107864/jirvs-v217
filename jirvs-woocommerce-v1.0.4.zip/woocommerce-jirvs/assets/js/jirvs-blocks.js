/**
 * Jirvs 支付网关：WooCommerce 区块结账页（Cart/Checkout Block）的前端注册脚本
 *
 * 纯原生 JS，不需要打包构建。WooCommerce 结账页加载时执行，
 * 把"Jirvs 支付"注册进支付方式列表。买家点下单后，
 * 照样走后端 WC_Gateway_Jirvs::process_payment()（跳转 Jirvs 收银台）。
 */
(function () {
    'use strict';

    var wcBlocks = window.wc && window.wc.wcBlocksRegistry;
    var wcSettings = window.wc && window.wc.wcSettings;
    var wpElement = window.wp && window.wp.element;

    // 区块环境没 ready（比如经典结账页）：什么都不做，直接退出
    if (!wcBlocks || !wcSettings || !wpElement) {
        return;
    }

    // PHP 传过来的标题/描述（后台"Jirvs 支付 → 管理"里可改）
    var data = wcSettings.getSetting('jirvs_data', {});
    var label = data.title || 'Jirvs 支付';
    var description = data.description || '';

    // 支付方式下面的说明文字
    var Content = function () {
        return wpElement.createElement(
            'div',
            { className: 'jirvs-payment-description' },
            description
        );
    };

    wcBlocks.registerPaymentMethod({
        name: 'jirvs',
        label: label,
        content: wpElement.createElement(Content),
        edit: wpElement.createElement(Content),
        // 下单按钮能不能点：后端 is_available() 已经判过，这里恒为 true
        canMakePayment: function () {
            return true;
        },
        ariaLabel: label,
        supports: {
            // 只声明支持普通商品；订阅类产品以后再加
            features: ['products']
        }
    });
})();
